<?php require 'header.php' ?>
<div class="columns">
	<div class="left">
		
		blabla


		<div class="bloopers">
				<?php for ($i=0; $i <4 ; $i++) { ?>
			<div class="blooper">
				<div class="bg-image">bg-bild</div>
				<div class="blooper-text">
					<div class="heading">Rosor</div>
					<div class="text">Lorem ipsum</div>
				</div>
			</div>
			<?php } ?>
		</div>
		
	</div>
	<div class="right"></div>
</div><!-- /columns -->
<?php require 'footer.php' ?>
