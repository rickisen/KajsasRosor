<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<title>Kajsas rosor</title>
	<meta http-equiv="content-type" content="text/html;charset=UTF-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
​	<div class="wrapper">
		<header>
			<div class="inner">
				<div class="logo">logga</div>	
				<div class="mobile-toggle" id="mobile-toggle">hamburgare</div>
			</div>

			<div class="slogan">slogan</div>
			<div class="menu-container" id="menu">menycontainer</div>
		</header>


		<div class="hero">hero image</div>
		<div class="page-container">
			<div class="page-title">Sidans titel</div>
			

