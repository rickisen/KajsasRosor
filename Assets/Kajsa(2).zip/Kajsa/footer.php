			<footer>
				<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/1.18.3/TweenMax.min.js"></script>
				<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/1.18.3/plugins/ScrollToPlugin.min.js"></script>
				<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.3.min.js"></script>
				<script type="text/javascript" src="main.js"></script>
			</footer>
			</div>
	</div>
</body>
</html>