$(document).ready(function(){

	$('#mobile-toggle').on('click', function(){
		$('#menu').slideToggle();
	});

});